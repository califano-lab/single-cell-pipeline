#' Length of rows for arrays with NA values
#'
#' This function report the length of rows of a matrix ignoring the NA values
#'
#' @param x Matrix
#' @return Integer indicating the number of non-NA rows
#' @export

rlength <- function(x) {
  r <- x/x
  r[x==0] <- 1
  r[!is.finite(r)] <- 0
  r %*% rep(1,ncol(r))
}

#' Length of columns of arrays with NAs
#'
#' This function report the number of columns of a matrix ignoring NA values
#'
#' @param x Matrix
#' @return Integer indicating the number of non-NA columns
#' @export

clength <- function(x) rlength(t(x))

#' Sum by rows
#'
#' This function performs a sum by rows ignoring NA values
#'
#' @param x Numeric matrix
#' @return Numeric vector
#' @export

rsum <- function(x) {
	x[is.na(x)] <- 0
	res <- x %*% rep(1, ncol(x))
	names(res) <- rownames(x)
	res
}

#' Sum by columns
#'
#' This function performs a sum by columns ignoring NA values
#'
#' @param x Numeric matrix
#' @return numeric vector
#' @export

csum <- function(x) rsum(t(x))

#' Mean of rows for arrays with NA values
#'
#' This function compute the mean by rows ignoring NA values
#'
#' @param x Numeric matrix
#' @return Numeric vector
#' @export

rmean <- function(x) {
  largo <- rlength(x)
  x[is.na(x)] <- 0
  res <- x %*% rep(1,ncol(x)) / largo
  names(res) <- rownames(x)
  res
}

#' Mean of columns for arrays with NA values
#'
#' This function computes the mean by columns ignoring NA values
#'
#' @param x Numeric matrix
#' @return Numeric vector
#' @export

cmean <- function(x) rmean(t(x))

#' Variance of rows for arrays with NA values
#'
#' This function computes the variance by rows ignoring NA values
#'
#' @param x Numeric matrix
#' @return Numeric vector
#' @export

rvar <- function(x) {
  ave <- as.vector(rmean(x))
  pos <- which(is.na(x))
  largo <- rlength(x)
  x[pos] <- rep(ave,ncol(x))[pos]
  (x-ave)^2 %*% rep(1,ncol(x))/(largo-1)
}

#' Variance of columns for arrays with NA values
#'
#' This function computes the variance by columns ignoring NA values
#'
#' @param x Numeric matrix
#' @return Numeric vector
#' @export

cvar <- function(x) rvar(t(x))

#' Weighted mean of columns
#'
#' This function computes the weighted mean by columns
#'
#' @param x Numeric matrix
#' @param qs Vector of weights whith length equals the number of rows in \code{x}
#' @return Numeric vector
#' @export

cwmean <- function(x, qs) {
  qs[is.na(x)] <- 0
  x[is.na(x)] <- 0
  qss <- matrix(rep(1, nrow(qs)), 1, nrow(qs)) %*% qs
  cociente <- t(matrix(rep(qss, nrow(qs)), ncol(qs), nrow(qs)))
  cociente[cociente==0] <- 1
  qs <- qs / cociente
  x <- x * qs
  res <- matrix(rep(1, nrow(x)), 1, nrow(x)) %*% x
  res[res==0] <- NA
  res
}

#' Weighted mean of rows
#'
#' This function computes the weighted mean by rows
#'
#' @param x Numeric matrix
#' @param qs Vector of weights with length equals the number of columns in \code{x}
#' @return Numeric vector
#' @export

rwmean <- function(x, qs) cwmean(t(x), t(qs))

#' t-test of rows for arrays with NA values
#'
#' This function performs a t-test by rows
#'
#' @param x Numeric matrix representing the phenotype samples
#' @param y Optional numeric matrix representing the control samples
#' @param mu Number indicating the null hypothesis value to be used when \code{y} is ommited
#' @param alternative Character string indicating the tail to test, either two.sided, greater or less
#' @return A list with two components: \describe{
#' \item{statistic}{t-test statistic}
#' \item{p.value}{p-value}
#' }
#' @export

rtt <- function(x, y=NULL, mu=0, alternative="two.sided") {
  largo <- rlength(x)
  if (is.null(y)) {
    t <- (rmean(x)-mu)/sqrt(rvar(x)/largo)
    list(statistic=t,p.value=switch(pmatch(alternative, c("two.sided", "greater", "less")), pt(abs(t),largo-1,lower.tail=F)*2, pt(t, largo-1, lower.tail=F), pt(t, largo-1, lower.tail=T)))
  }
  else {
    largoy <- rlength(y)
    t <- (rmean(x)-rmean(y))/sqrt(((largo-1)*rvar(x)+(largoy-1)*rvar(y))/(largo+largoy-2))/sqrt(1/largo+1/largoy)
    list(statistic=t,p.value=switch(pmatch(alternative, c("two.sided", "greater", "less")), pt(abs(t),largo+largoy-2,lower.tail=F)*2, pt(t, largo+largoy-2, lower.tail=F), pt(t, largo+largoy-2, lower.tail=T)))
  }
}

#' Coeficient of variations for rows
#'
#' This function computes the coefficient of variation (CV) by rows
#'
#' @param x Numeric matrix
#' @return Numeric vector
#' @export

rcv <- function(x) sqrt(rvar(x))/rmean(x)

#' Summarizes matrix
#'
#' This function summarizes the rows of a matrix in different ways
#'
#' @param x Numeric matrix
#' @param method Summarization method, either max, min, mean or median
#' @return Numeric vector containing the absolute maximum, minimum, mean or media value for each row
#' @export

summarize <- function(x, method=c("max","min","mean","median")[1]) {
  options(warn=-1)
  on.exit(options(warn=0))
  method <- match.arg(method, choices=c("max","min","mean","median"))
  switch(method, max=apply(as.matrix(x),1,function(x) x[abs(x)==max(abs(x),na.rm=T)][1]),
    min=apply(as.matrix(x),1,function(x) x[abs(x)==min(abs(x),na.rm=T)]),
    mean=rmean(as.matrix(abs(x))),
    median=apply(as.matrix(abs(x)),1,median,na.rm=T)
  )
}

#' Weighted means by columns
#' 
#' This function computes weighted means for the columns of a matrix
#' 
#' @param x Numeric matrix
#' @param w Numeric vector of weights of length equal to matrix \code{x} rows
#' @return Vector of weighted means
#' @export
colWMeans <- function(x, w) {
    w <- w/sum(w, na.rm=TRUE)
    colSums(x*w, na.rm=TRUE)
}

#' Weighted variance by columns
#' 
#' This function computes weighted variance for the columns of a matrix
#' 
#' @param x Numeric matrix
#' @param w Numeric vector of weights of length equal to matrix \code{x} rows
#' @return Vector of weighted variance
#' @export
colWVars <- function(x, w) {
    w <- w/sum(w, na.rm=TRUE)
    m <- colSums(x*w, na.rm=TRUE)
    colSums(w * t((t(x)-m)^2), na.rm=TRUE)
}

#' Weighted means by rows
#' 
#' This function computes weighted means for the rows of a matrix
#' 
#' @param x Numeric matrix
#' @param w Numeric vector of weights of length equal to matrix \code{x} columns
#' @return Vector of weighted means
#' @export
rowWMeans <- function(x, w) colWMeans(t(x), w)

#' Weighted variance by rows
#' 
#' This function computes weighted variance for the rows of a matrix
#' 
#' @param x Numeric matrix
#' @param w Numeric vector of weights of length equal to matrix \code{x} columns
#' @return Vector of weighted variance
#' @export
rowWVars <- function(x, w) colWVars(t(x), w)

