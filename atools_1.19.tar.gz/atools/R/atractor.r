#' Attractor
#' 
#' This function search for attractor metagenes or metasamples by iterative correlation analysis
#' 
#' @param dset Expression data-set with genes in rows and samples in columns (for attractor metagene) or the transpose (for attractor metasamples)
#' @param mse Mean squared error when convergence is reached
#' @param r2 Determination coefficient when convergence is reached
#' @param item Integer indicating the maximum number of iterations
#' @param ep Exponent parameter
#' @param method Correlation method, either pearson, spearman, kendall or signature
#' @param scale. Logical, whether the dataset must be scaled before the analysis
#' @param absolute Logical, whether the absolute distace should be used
#' @param genes Integer indicating the number of genes (samples) to consider when using the signature method
#' @return Matrix of metagenes or metasamples
#' @export

attractor <- function(dset, mse=1e-6, r2=.99, iter=100, ep=2, method="pearson", scale.=T, absolute=T, genes=500) {  
  if (scale.) dset <- t(scale(dset))
  da <- dset
  r21 <- 0
  mse1 <- 1e6
  i <- 1
  cat("\n")
  while(mse1>mse & r21<r2 & i<iter) {
    d1 <- da
    if (method != "signature") cm <- cor(dset, da, method=method)
    else cm <- signatureDistance(dset=dset, dset2=da, nn=genes, symmetric=F, nes=T)
    if (!absolute) cm <- (cm-min(cm))
    cm <- (abs(cm)/max(abs(cm)))^ep
    cm <- t(t(cm) / colSums(cm))
    da <- dset %*% t(cm) # Check whether the transpose is correct
    mse1 <- sum((d1-da)^2)
    r21 <- cor(as.vector(d1), as.vector(da))^2
    cat("Iteration: ", i, ", MSE: ", mse1, ", R2: ", round(r21, 3), "\n", sep="")
    i <- i+1
  }
  return(da)
}

  
  #   res <- lapply(1:ncol(dset), function(i, dset, mse, iter) {
#     niter=0
#     mg <- filterColMatrix(dset, i)
#     rr <- 0
#     nes <- dset[1, ]
#     while(rr<r2 & niter<iter) {
#       target <- nes
#      nes <- signatureDistance(mg, dset, nn=nn, two.tails=F, nes=T, scale.=F)
#      nes <- -log10(pnorm(nes, lower.tail=F))
#      nes[!is.finite(nes)] <- max(nes[is.finite(nes)])
#       nes <- abs(cor(mg, dset))
#       mg <- colSums(t(dset)*as.vector(nes/sum(nes)))
#       mg <- matrix(mg, length(mg), 1, dimnames=list(names(mg), NULL))
#       niter <- niter+1
#       rr <- cor(as.vector(nes), as.vector(target))^2
#       cat("Iter: ", niter, ", mse: ", round(rr, 3), "\n")
#     }  
#     list(nes=nes[1, ], mg=mg[, 1])
#   }, dset=t(scale(t(dset))), mse=mse, iter=iter)
#   return(res)
# }
