#' BarPlots
#'
#' This function render barplots with error bars
#'
#' @param x Vector of vars height
#' @param err Vector of size for the error bars
#' @param ... Additional parameters to be passed to \code{barplot} function
#' @return Nothing, a graph is generated as side effect
#' @export

barPlot <- function(x, err, ...) {
  rr <- range(c(x+err, x-err))*1.05
  if (rr[1]>0) rr[1] <- 0
	if (rr[2]<0) rr[2] <- 0
  barplot(x, .8, .25, ylim=rr, ...)
  abline(h=0)
  for(i in 1:length(err)) {lines(c(i, i)-.4, c(x[i]-err[i], x[i]+err[i])); lines(c(i-.1, i+.1)-.4, c(x[i]-err[i], x[i]-err[i])); lines(c(i-.1, i+.1)-.4, c(x[i]+err[i], x[i]+err[i]))}
}

