# MI and correlation analysis

#' @importFrom ks Hpi
#' @importFrom ks kde
#' @importFrom parallel mclapply
#' @importFrom parallel mc.reset.stream
#' @importFrom e1071 interpolate
#' @importFrom KernSmooth bkde2D 
NULL

#' Mutual information
#' 
#' This function estimates the mutual information between continuous variables using a fix bandwidth implementation
#' 
#' @param x Numeric vector or matrix
#' @param y Optional numeric vector or matrix
#' @param per Integer indicating the number of permutations to compute p-values
#' @param pairwise Logical, wether columns of x and y should be compared in a pairwise maner. x and y must have the same number of columns
#' @param bw Integer indicating the grid size for integrating the joint probability density
#' @param cores Integer indicating the number of cores to use (1 for Windows-based systems)
#' @param verbose Logical, whether progression bars should be shown
#' @return Numeric value, vector or matrix of results
#' @description This function estimates the mutual information between x and y given both are numeric vectors, between the columns of x if it is a numeric matrix, or between the columns of x and y if both are numeric matrixes
#' @export
#' @examples
#' x <- seq(0, pi, length=100)
#' y <- 5*sin(x)+rnorm(100)
#' cor.test(x, y)
#' mutualInfo(x, y, per=100)
mutualInfo <- function(x, y=NULL, per=0, pairwise=FALSE, bw=100, cores=1, verbose=TRUE){
    pb <- NULL
    if (verbose) message("Estimating kernel bandwidth...")
    if (is.matrix(x)) {
        x <- qnorm(apply(x, 2, rank)/(nrow(x)+1))
        if (is.null(y)) {
            h <- min(choose(ncol(x), 2), bw)
            tmp <- combn(min(100, ncol(x)), 2)
            tmp <- tmp[, sample(ncol(tmp), h)]
            if (cores==1) {
                h <- apply(tmp, 2, function(i, x) {
                    Hpi(x[, i])
                }, x=x)
            }
            else {
                h <- mclapply(1:ncol(tmp), function(i, tmp, x) {
                    Hpi(x[, tmp[, i]])
                }, tmp=tmp, x=x, mc.cores=cores)
                h <- sapply(h, function(x) x)
            }
            tmp <- apply(h, 1, rank)-(ncol(h)/2)
            tmp <- which.min(abs(rowMeans(tmp)))
            h <- matrix(h[, tmp], 2, 2)
            if (verbose) message("Computing MI...")
            if (cores==1) {
                if (verbose) {
                    pb <- txtProgressBar(max=ncol(x)-1, style=3)
                }
                tmp <- lapply(1:(ncol(x)-1), function(i, x, h, pb) {
                    if (!is.null(pb)) setTxtProgressBar(pb, i)
                    apply(filterColMatrix(x, (i+1):ncol(x)), 2, function(x1, x2, h) {
                        internalMIfb(x1, x2, h=h)
                    }, x2=x[, i], h=h)
                }, x=x, h=h, pb=pb)
            }
            else {
                tmp <- mclapply(1:(ncol(x)-1), function(i, x, h) {
                    apply(filterColMatrix(x, (i+1):ncol(x)), 2, function(x1, x2, h) {
                        internalMIfb(x1, x2, h=h)
                    }, x2=x[, i], h=h)
                }, x=x, h=h, mc.cores=cores)
            }
            tmp <- unlist(tmp, use.names=FALSE)
            mi <- matrix(NA, ncol(x), ncol(x))
            mi[lower.tri(mi)] <- tmp
            mi <- t(mi)
            mi[lower.tri(mi)] <- tmp
            rownames(mi) <- colnames(mi) <- colnames(x)
        }
        else {
            if (is.matrix(y)) {
                y <- qnorm(apply(y, 2, rank)/(nrow(y)+1))
                if (ncol(x)==ncol(y) & pairwise) {
                    h <- min(ncol(x), bw)
                    tmp <- sample(ncol(x), h)
                    if (cores==1) {
                        h <- sapply(tmp, function(i, x, y) {
                            Hpi(cbind(x[, i], y[, i]))
                        }, x=x, y=y)
                    }
                    else {
                        h <- mclapply(tmp, function(i, x, y) {
                            Hpi(cbind(x[, i], y[, i]))
                        }, x=x, y=y, mc.cores=cores)
                        h <- sapply(h, function(x) x)
                    }
                    tmp <- apply(h, 1, rank)-(ncol(h)/2)
                    tmp <- which.min(abs(rowMeans(tmp)))
                    h <- matrix(h[, tmp], 2, 2)
                    if (verbose) message("Computing MI...")
                    if (cores==1) {
                        if (verbose) {
                            pb <- txtProgressBar(max=ncol(x), style=3)
                        }                        
                        mi <- sapply(1:ncol(x), function(i, x, y, h, pb) {
                            if (!is.null(pb)) setTxtProgressBar(pb, i)
                            internalMIfb(x[, i], y[, i], h=h)
                        }, x=x, y=y, h=h, pb=pb)
                    }
                    else {
                        mi <- mclapply(1:ncol(x), function(i, x, y, h) {
                            internalMIfb(x[, i], y[, i], h=h)
                        }, x=x, y=y, h=h, mc.cores=cores)
                        mi <- unlist(mi, use.names=FALSE)
                    }
                    names(mi) <- colnames(x)
                }
                else {
                    h <- min(ncol(x)*ncol(y), bw)
                    tmp <- rbind(rep(1:ncol(x), rep(ncol(y), ncol(x))), rep(1:ncol(y), ncol(x)))[, sample(h)]
                    if (cores==1) {
                        h <- apply(tmp, 2, function(i, x, y) {
                            Hpi(cbind(x[, i[1]], y[, i[2]]))
                        }, x=x, y=y)
                    }
                    else {
                        h <- mclapply(1:ncol(tmp), function(i, tmp, x, y) {
                            i <- tmp[, i]
                            Hpi(cbind(x[, i[1]], y[, i[2]]))
                        }, x=x, y=y, tmp=tmp, mc.cores=cores)
                        h <- sapply(h, function(x) x)
                    }
                    tmp <- apply(h, 1, rank)-(ncol(h)/2)
                    tmp <- which.min(abs(rowMeans(tmp)))
                    h <- matrix(h[, tmp], 2, 2)
                    if (verbose) message("Computing MI...")
                    if (cores==1) {
                        if (verbose) {
                            pb <- txtProgressBar(max=ncol(y), style=3)
                        }
                        mi <- sapply(1:ncol(y), function(i, x, y, h, pb) {
                            y <- y[, i]
                            if (!is.null(pb)) setTxtProgressBar(pb, i)
                            apply(x, 2, function(x, y, h) {
                                internalMIfb(x, y, h=h)
                            }, y=y, h=h)
                        }, x=x, y=y, h=h, pb=pb)
                    }
                    else {
                        mi <- mclapply(1:ncol(y), function(i, x, y, h) {
                            y <- y[, i]
                            apply(x, 2, function(x, y, h) {
                                internalMIfb(x, y, h=h)
                            }, y=y, h=h)
                        }, x=x, y=y, h=h, mc.cores=cores)
                        mi <- sapply(mi, function(x) x)
                    }
                    colnames(mi) <- colnames(y)
                    rownames(mi) <- colnames(x)
                }
            }
            else {
                y <- qnorm(rank(y)/(length(y)+1))
                h <- min(ncol(x), bw)
                tmp <- sample(ncol(x), h)
                if (cores==1) {
                    h <- apply(x[, tmp], 2, function(x, y) {
                        Hpi(cbind(x, y))
                    }, y=y)
                }
                else {
                    h <- mclapply(tmp, function(i, x, y) {
                        x <- x[, i]
                        Hpi(cbind(x, y))
                    }, x=x, y=y, mc.cores=cores)
                    h <- sapply(h, function(x) x)
                }
                tmp <- apply(h, 1, rank)-(ncol(h)/2)
                tmp <- which.min(abs(rowMeans(tmp)))
                h <- matrix(h[, tmp], 2, 2)
                if (verbose) message("Computing MI...")
                if (cores==1) {
                    if (verbose) {
                        pb <- txtProgressBar(max=ncol(x), style=3)
                    }
                    mi <- sapply(1:ncol(x), function(i, x, y, h, pb) {
                        x <- x[, i]
                        if (!is.null(pb)) setTxtProgressBar(pb, i)
                        internalMIfb(x, y, h=h)
                    }, y=y, h=h, x=x, pb=pb)
                }
                else {
                    mi <- mclapply(1:ncol(x), function(i, x, y, h) {
                        x <- x[, i]
                        internalMIfb(x, y, h=h)
                    }, y=y, h=h, x=x, mc.cores=cores)
                    mi <- unlist(mi, use.names=FALSE)
                }
                names(mi) <- colnames(x)
            }
        }
    }
    else {
        if (is.null(y)) stop("y is required when x is a numeric vector", call.=FALSE)
        x <- qnorm(rank(x)/(length(x)+1))
        if (is.matrix(y)) {
            y <- qnorm(apply(y, 2, rank)/(nrow(y)+1))
            h <- min(ncol(y), bw)
            tmp <- sample(ncol(y), h)
            if (cores==1) {
                h <- apply(y[, tmp], 2, function(y, x) {
                    Hpi(cbind(x, y))
                }, x=x)
            }
            else {
                h <- mclapply(tmp, function(i, y, x) {
                    y <- y[, i]
                    Hpi(cbind(x, y))
                }, x=x, y=y, mc.cores=cores)
                h <- sapply(h, function(x) x)
            }
            tmp <- apply(h, 1, rank)-(ncol(h)/2)
            tmp <- which.min(abs(rowMeans(tmp)))
            h <- matrix(h[, tmp], 2, 2)
            if (verbose) message("Computing MI...")
            if (cores==1) {
                if (verbose) {
                    pb <- txtProgressBar(max=ncol(y), style=3)
                }
                mi <- sapply(1:ncol(y), function(i, x, y, h, pb) {
                    y <- y[, i]
                    if (!is.null(pb)) setTxtProgressBar(pb, i)
                    internalMIfb(x, y, h=h)
                }, y=y, h=h, x=x, pb=pb)
            }
            else {
                mi <- mclapply(1:ncol(y), function(i, x, y, h) {
                    y <- y[, i]
                    internalMIfb(x, y, h=h)
                }, y=y, h=h, x=x, mc.cores=cores)
                mi <- unlist(mi, use.names=FALSE)
            }
            names(mi) <- colnames(y)
        }
        else {
            y <- qnorm(rank(y)/(length(y)+1))
            h <- Hpi(cbind(x, y))
            mi <- internalMIfb(x, y, h=h)
        }
    }
    if (!is.null(pb)) message("\n")    
    if (per>0) {
        if (is.matrix(x)) dnull <- qnorm((1:nrow(x))/(nrow(x)+1))
        else dnull <- qnorm((1:length(x))/(length(x)+1))
        if (verbose) message("Computing MI null model...")
        if (cores==1) {
            if (verbose) {
                pb <- txtProgressBar(max=per, style=3)
            }
            nullmi <- sapply(1:per, function(i, dnull, h, pb) {
                if (!is.null(pb)) setTxtProgressBar(pb, i)
                internalMIfb(sample(dnull), sample(dnull), h=h)
            }, dnull=dnull, h=h, pb=pb)
        }
        else {
            nullmi <- mclapply(1:per, function(i, dnull, h) {
                internalMIfb(sample(dnull), sample(dnull), h=h)
            }, dnull=dnull, h=h, mc.cores=cores)
            nullmi <- sapply(nullmi, function(x) x)
        }
        tmp <- aecdf(nullmi)
        tmp <- lapply(as.vector(mi), function(x, tmp) tmp(x, alternative="greater"), tmp=tmp)
        z <- sapply(tmp, function(x) x$nes)
        p <- sapply(tmp, function(x) x$p.value)
        dim(z) <- dim(p) <- dim(mi)
        if (!is.null(nrow(mi))) {
            colnames(z) <- colnames(p) <- colnames(mi)
            rownames(z) <- rownames(p) <- rownames(mi)
        }
        else names(z) <- names(p) <- names(mi)
        return(list(mi=mi, z=z, p.value=p))
    }
    if (is.null(pb)) message("\n")
    return(mi)
}

internalMIfb <- function(x, y, h, n=10) {
    x1 <- rep(seq(min(x), max(x), length=n), rep(n, n))
    y1 <- rep(seq(min(y), max(y), length=n), n)
    k1 <- dnorm(x1)
    k2 <- dnorm(y1)
    k12 <- kde(cbind(x, y), h, xmin=c(min(x), min(y)), xmax=c(max(x), max(y)), eval.points=cbind(x1, y1))$estimate
    sum(k12*log10(k12/k1/k2), na.rm=T)/n^2*(max(x)-min(x))
}

#' Correlation test
#' 
#' This function computes correlation and associated p-values
#' 
#' @param x Numeric vector or matrix
#' @param y Optional numeric vector or matrix
#' @param method Character string indicating the correlation method
#' @param pairwise Logical, wether columns of x and y should be compared in a pairwise manner. x and y must have the same number of columns
#' @return Numeric value, vector or matrix or results
#' @description This function computes the correlation between x and y given both are numeric vectors, between the columns of x if it is a numeric matrix, or between the columns of x and y if both are numeric matrixes
#' @export
#' @examples
#' x <- seq(0, 10, length=50)
#' y <- x+rnorm(length(x), sd=2)
#' correlation(x, y)
correlation <- function(x, y=NULL, method=c("pearson", "spearman", "kendall"), pairwise=FALSE){
    method <- match.arg(method)
    if (is.matrix(x)) {
        n <- nrow(x)
        if (is.matrix(y)) {
            if (ncol(x)==ncol(y) & pairwise) {
                mi <- sapply(1:ncol(x), function(i, x, y) {
                    cor(x[, i], y[, i], method=method, use="pairwise.complete.obs")
                }, x=x, y=y)
                names(mi) <- colnames(x)
                if ((sum(is.na(x))+sum(is.na(y)))>0) {
                    n <- sapply(1:ncol(x), function(i, x, y) {
                        length(which(rowSums(!is.na(cbind(x[, i], y[, i])))==2))
                    }, x=x, y=y)
                }
            }
            else {
                mi <- cor(x, y, method=method, use="pairwise.complete.obs")
                if ((sum(is.na(x))+sum(is.na(y)))>0) {
                    n <- sapply(1:ncol(y), function(i, x, y) {
                        sapply(1:ncol(x), function(ii, x, y, i) {
                            length(which(rowSums(!is.na(cbind(x[, ii], y[, i])))==2))
                        }, x=x, y=y, i=i)
                    }, x=x, y=y)
                }
            }
        }
        else {
            y <- matrix(y, length(y), 1, dimnames=list(names(y), "y"))
            mi <- cor(x, y, method=method, use="pairwise.complete.obs")
            if ((sum(is.na(x))+sum(is.na(y)))>0) {
                n <- sapply(1:ncol(x), function(i, x, y) {
                    length(which(rowSums(!is.na(cbind(x[, i], y)))==2))
                }, x=x, y=y)
            }
        }
    }
    else {
        n <- length(x)
        if (is.null(y)) stop("y is required when x is a numeric vector", call.=FALSE)
        if (is.matrix(y)) {
            x <- matrix(x, length(x), 1, dimnames=list(names(x), "x"))
        }
        else {
            x <- matrix(x, length(x), 1, dimnames=list(names(x), "x"))
            y <- matrix(y, length(x), 1, dimnames=list(names(x), "x"))
        }
        mi <- cor(x, y, method=method, use="pairwise.complete.obs")
        if ((sum(is.na(x))+sum(is.na(y)))>0) {
            n <- sapply(1:ncol(y), function(i, x, y) {
                length(which(rowSums(!is.na(cbind(x, y[, i])))==2))
            }, x=x, y=y)
        }
    }
    tmp <- cortest(mi, n)
    return(list(r=mi, z=tmp$z, p.value=tmp$p.value))
}

#' approxk2d
#' 
#' This function uses a gaussian kernel to estimate the joint density distribution at the specified points
#' 
#' @param x Matrix of x and y points
#' @param gridsize number or vector indicating the size of the greed where to estimate the density
#' @param pos Matrix of coordinates to evaluate the density
#' @return Vector of density estimates
#' @examples
#' x <- rnorm(500)
#' y <- x+rnorm(500)
#' kde2 <- approxk2d(cbind(x, y))
#' plot(x, y, pch=20, col=hsv(0, kde2/max(kde2), 1))
#' @export

approxk2d <- function(x, gridsize=128, pos=x) {
    bw <- diff(apply(x, 2, quantile, probs = c(0.05, 0.95), na.rm = TRUE, names = FALSE))/25
    bw[bw == 0] <- 1
    if (length(gridsize)==1) gridsize <- rep(gridsize, 2)
    tmp <- bkde2D(x, bandwidth=bw, gridsize=gridsize[1:2])
    return(e1071::interpolate(pos, tmp$fhat, adims=list(tmp$x1, tmp$x2)))
}

#' kld2d
#' 
#' Kullback-Liebler divergence for bivariate distributions
#' 
#' @param x Two columns matrix with data for the reference distribution
#' @param y Two columns matrix with data for the test distribution
#' @param gridsize Grid size
#' @examples
#' x <- rnorm(100)
#' x <- cbind(x, x+rnorm(100))
#' y <- rnorm(100, 2)
#' y <- cbind(y, y+rnorm(100))
#' kld2d(x, y)
#' @export
kld2d <- function(x, y, gridsize=128, per=1, cores=1) {
    xy <- rbind(x, y)
    xy <- apply(xy, 2, rank)/(nrow(xy)+1)
    y <- xy[-(1:nrow(x)), ]
    x <- xy[1:nrow(x), ]
    rm(xy)
    bwx <- Hpi(x)
    bwy <- Hpi(y)
    if (per>1) {
        z <- rbind(x, y)
        nulld <- unlist(mclapply(1:per, function(i, z, size, gz, bwx, bwy) {
            pos <- sample(nrow(z), size)
            .kld2d(z[-pos, ], z[pos, ], gridsize=gz)
        }, z=z, size=nrow(y), gz=gridsize, bwx=bwx, bwy=bwy, mc.cores=cores), use.names=FALSE)
        tmp <- .kld2d(x, y, bwx, bwy, gridsize)
        tmp1 <- aecdf(nulld)(tmp, alternative="greater")
        return(list(kld=tmp, z=tmp1$nes, p.value=tmp1$p.value, bwx, bwy))
    }
    else {
        return(list(.kld2d(x, y, bwx, bwy, gridsize), bwx, bwy))
    }
}

.kld2d <- function(x, y, bwx, bwy, gridsize) {     
    p <- kde(x, bwx, gridsize=gridsize, xmin=c(0, 0), xmax=c(1, 1))$estimate
    q <- kde(y, bwy, gridsize=gridsize, xmin=c(0, 0), xmax=c(1, 1))$estimate
    p <- p+(min(p[p>0])/2)
    q <- q+(min(q[q>0])/2)
    p <- p/sum(p)
    q <- q/sum(q)
    return(sum(p*log(p/q)))
}





#' kld2da
#' 
#' Kullback-Liebler divergence for bivariate distributions
#' 
#' @param x Two columns matrix with data for the reference distribution
#' @param y Two columns matrix with data for the test distribution
#' @param gridsize Grid size
#' @examples
#' x <- rnorm(100)
#' x <- cbind(x, x+rnorm(100))
#' y <- rnorm(100, 2)
#' y <- cbind(y, y+rnorm(100))
#' kld2d(x, y)
#' @export
kld2da <- function(x, y, gridsize=128, per=1, cores=1) {
    if (per>1) {
        z <- rbind(x, y)
        nulld <- unlist(mclapply(1:per, function(i, z, size, gz) {
            pos <- sample(nrow(z), size)
            .kld2d(z[-pos, ], z[pos, ], gridsize=gz)
        }, z=z, size=nrow(y), gz=gridsize, mc.cores=cores), use.names=FALSE)
        tmp <- .kld2d(x, y, gridsize)
        tmp1 <- aecdf(nulld)(tmp, alternative="greater")
        return(list(kld=tmp, z=tmp1$nes, p.value=tmp1$p.value))
    }
    else {
        return(.kld2d(x, y, gridsize))
    }
}

.kld2da <- function(x, y, gridsize) {     
    bwx <- diff(apply(x, 2, quantile, probs = c(0.05, 0.95), na.rm = TRUE, names = FALSE))/25
    bwx[bwx == 0] <- 1
    bwy <- diff(apply(y, 2, quantile, probs = c(0.05, 0.95), na.rm = TRUE, names = FALSE))/25
    bwy[bwy == 0] <- 1
    bw <- c(max(bwx[1], bwy[1]), max(bwx[2], bwy[2]))
    range.x <- apply(rbind(x, y), 2, range)+1.5*c(-bw[1], bw[1], -bw[2], bw[2])
    p <- bkde2D(x, bandwidth=bwx, gridsize=rep(gridsize, 2), range.x=list(range.x[, 1], range.x[, 2]))$fhat
    q <- bkde2D(y, bandwidth=bwy, gridsize=rep(gridsize, 2), range.x=list(range.x[, 1], range.x[, 2]))$fhat
    p <- p+(min(p[p>0])/2)
    q <- q+(min(p[p>0])/2)
    p <- p/sum(p)
    q <- q/sum(q)
    return(sum(p*log(p/q)))
}

