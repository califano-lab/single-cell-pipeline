#' Parse Expression-set
#'
#' This function parses an expression-set file
#'
#' @param filename Character string indicating the expression-set file name
#' @return List of two components: \describe{
#' \item{dset}{Matrix containing the dataset}
#' \item{annotation}{Names vector of genes with probes as name argument}
#' }
#' @export

parseExpset <- function(filename) {
  db <- readLines(filename)  
  db <- strsplit(db, "\t", extended=F)
  res <- t(sapply(db[-1], function(x) as.numeric(x[-(1:2)])))
  colnames(res) <- db[[1]][-(1:2)]
  annot <- sapply(db[-1], function(x) x[2])
  rownames(res) <- names(annot) <- sapply(db[-1], function(x) x[1])
  return(list(dset=res, annotation=annot))
}

#' Select probes with the highest CV
#'
#' This function selects the probes showing the highest CV
#'
#' @param expset Numeric matrix
#' @param annotation Named vector of genes wth probes as name attribute
#' @return Vector of probeIDs
#' @export

bestProbe <- function(expset, annotation) {
  escv <- rcv(expset)[, 1]
  pos <- split(1:length(escv), factor(annotation[match(names(escv), names(annotation))]))
  filtro <- sapply(pos, length)>1
  probes <- names(escv)[unlist(pos[!filtro], use.names=F)]
  probes <- c(probes, sapply(pos[filtro], function(x, escv) names(escv)[x][which.max(escv[x])], escv=escv))
  return(probes)
}

