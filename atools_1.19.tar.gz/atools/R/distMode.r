#' Mode of continuous distributions
#' 
#' This function computes the mode for continuous distributions
#' 
#' @param x Numeric vector of data
#' @param adj Number indicating the adjustment for the bandwidth estimated by the \code{density} function using bw=SJ
#' @return number
#' @export
distMode <- function(x, adj=1) {
  tmp <- density(x, adjust=adj, na.rm=TRUE)
  return(tmp$x[which.max(tmp$y)])
}
