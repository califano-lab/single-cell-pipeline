#order expression-sets

expset.order <- function(expset, method=c("max","min","mean","median")[1], index=NULL) {
  if (names(expset)[1]=="expset") expset.order.i(expset, method=method, index=index)
  else lapply(expset, expset.order, method=method)
}

expset.order.i <- function(expset, method=c("max","min","mean","median")[1], index=NULL) {
  if (is.null(index)) {
    if (is.null(expset$fold)) orden <- rownames(expset$expset)[order(rownames(expset$expset))]
    else if (is.null(expset$p.value)) {
      fold.a <- summarize(as.matrix(expset$fold), method=method)
      orden <- rownames(expset$fold)[order(fold.a)]
    }
    else orden <- rownames(expset$p.value)[order(abs(expset$p.value))]
  }
  else orden <- rownames(expset$expset)[index]
  expset$expset <- filterRowMatrix(expset$expset, match(orden,rownames(expset$expset)))
  if (!is.null(expset$qs)) expset$qs <- filterRowMatrix(expset$qs, match(orden,rownames(expset$qs)))
  if (!is.null(expset$fold)) expset$fold <- filterRowMatrix(expset$fold, match(orden,rownames(expset$fold)))
  if (!is.null(expset$p.value)) expset$p.value <- filterRowMatrix(expset$p.value, match(orden,rownames(expset$p.value)))
  if (!is.null(expset$sem)) expset$sem <- filterRowMatrix(expset$sem, match(orden, rownames(expset$sem)))
  if (!is.null(expset$gene)) expset$gene <- expset$gene[match(orden,names(expset$gene))]
  if (!is.null(expset$description)) expset$description <- expset$description[match(orden,names(expset$description))]
  if (!is.null(expset$class)) expset$class <- expset$class[match(orden,names(expset$class))]
  if (!is.null(expset$go.class)) expset$go.class <- expset$go.class[match(orden,names(expset$go.class))]
  expset
}
