#' Filter redundant rows by CV
#'
#' This function eliminates redundant rows from a matrix based on coefficient of variation
#'
#' @param expset Numerical matrix whose names attribute is going to be used to identify redundant rows
#' @return Numerical matrix
#' @export

filterCV <- function(expset) {
  repet <- tapply(rownames(expset), factor(rownames(expset)), length)
  if (max(repet)>1) {
    d <- expset[rownames(expset) %in% (names(repet)[repet==1]),]  
    d1 <- expset[rownames(expset) %in% (names(repet)[repet>1]),]
    d2 <- tapply(1:nrow(d1),factor(rownames(d1)), function(pos, d1, cv) {
      list(name=rownames(d1)[pos][which.max(cv[pos])],value=d1[pos,][which.max(cv[pos]),])
    }, d1=d1, cv=rcv(d1))
    d3 <- t(sapply(d2, function(x) x$value))
    if (nrow(d3) != length(d2)) d3 <- t(d3)
    rownames(d3) <- sapply(d2, function(x) x$name)
    expset <- rbind(d,d3)
  }
  expset
}
