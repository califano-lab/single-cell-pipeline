#' FTP upload using the titan cluster
#' 
#' This function upload a set of files to a given FTP location using the titan cluster
#' 
#' @param fnames Vector of character string indicating the files to transfer
#' @param ftpserver Character string indicating the FTP server
#' @param ftpdir Character string indicating the target directory
#' @param usr Character string indicating the username
#' @param pwd Character string indicating the password
#' @param tout Number indicating the maximum time for the connection in seconds
ftpUpload <- function(fnames, ftpserver, ftpdir, usr, pwd, tout=14400) {
  for (i in fnames) {
    i1 <- paste("a", strsplit(i, "\\.")[[1]][1], sep="")
    cat("#!/bin/bash
#$ -cwd
#$ -j y
#$ -l mem=2G,time=6::
#$ -S /bin/bash
#$ -N ", i1, "
curl -vas --retry 10 -m ", tout, " -T ", i, " ftp://", usr, ":", pwd, "@", ftpserver, ftpdir, "
", sep="", file=paste(i1, ".sh", sep=""))
    system(paste("qsub ", i1, ".sh", sep=""))
  }
}



