#' Split a vector of strings
#'
#' This function splits a vector of strings into a matrix
#'
#' @param x Vector of strings to be splitted
#' @param st Character string to be used as separation for the split
#' @return Matrix
#' @export

strsplit_matrix <- function (x, st = "_")
{
    tr <- strsplit(x, st)
    tru <- unlist(tr, use.names=F)
    dim(tru) <- c(length(tr[[1]]), length(tr))
    t(tru)
}

#Power transform optimization
fpow <-  function(z,gg)
 optim(c(0,0.1), ftar1,z=z,gg=gg)$par

ftar1 <- function(a,z,gg) {
    x = sign(a[2])*(z-a[1])^a[2]
#    if( sum(is.na(x)) > 0) return(1)
    p = ncol(x)
    n = nrow(x)
    tgr = c(table(gg))
    ngr = length(tgr)
    i = rep(rep(0:1,ngr)[-1],c(rbind(p,tgr))[-1])
    dim(i) =c(p,ngr)
    im = t(t(i)/tgr)
    x1 <- x/x
    x1[is.na(x)] <- 0
    largo <- x1 %*% i
    largo[largo==0] <- 1
    xm = x1%*%i / largo
    xr = x1 - xm%*%t(i)
    r1 = f.cv( sqrt((xs<-rsum(xr^2))/(p-ngr)))
    r2 = mean(rsum(xr^3)^2/xs^3,na.rm=T)
    xs = sqrt(xr^2%*%i)
    sum(r1,r2,mean(diag(cor(xm,xs))^2))
}

#Filter for outliers
filtro.outlier <- function(data, cutoff = .05, cons = F) {
  filtro <- NULL
  outlin <- NULL
  for (i in 1:ncol(data)) {
    filtrot <- rtt(data[,-i],mu=data[,i])$p.value < cutoff & (!cons | abs(data[,i]) > abs(rmean(data[,-i])))
    outlin <- c(outlin,length.na(which(filtrot)))
    filtro <- c(filtro,filtrot)
  }
  dim(filtro) <- dim(data)
  data[filtro] <- NA
  list(data,outlin)
}

#Internal function for cutting heatmaps
cortes <- function(level) {
  pos <- NULL
  for (i in 2:length(level)) if (level[i] != level[i-1]) pos <- c(pos,i)
  pos
}

#' Filter for rows of a matrix with no loss of col and row names
#'
#' This function filters the rows of a matrix returning always a two dimensional matrix
#'
#' @param x Matrix
#' @param filter Logical or numerical index of rows
#' @return Matrix
#' @export

filterRowMatrix <- function(x, filter) {
  if (is.logical(filter)) largo <- length(which(filter))
  else largo <- length(filter)
  matrix(x[filter, ], largo, ncol(x), dimnames=list(rownames(x)[filter], colnames(x)))
}

#' Filter for columns of a matrix with no loss of col and row names
#'
#' This function filters the columns of a matrix returning always a two dimensional matrix
#'
#' @param x Matrix
#' @param filter Logical or numerical index of columns
#' @return Matrix
#' @export

filterColMatrix <- function(x, filter) t(filterRowMatrix(t(x), filter))


list.names <- function(x) names(unlist(nombres.i(x)))

nombres.i <- function(x) {
  if (!(names(x)[1] %in% c("expset","go.fold","expset.cluster","cor"))) lapply(x, nombres.i)
  else " "
}

#' Geometric mean
#'
#' This function computes the geometric mean of a vector
#'
#' @param x Numerical vector
#' @return Number
#' @export

gmean <- function(x) exp(mean(log.na(x)))

#Open PDF for output
devicePDF <- function(w=7, h=7, ...) {
  a <- list.files()
  pos <- grep("RPlot", a)
  fname <- "RPlot_1.pdf"
  if (length(pos)>0) {
    a <- max(as.numeric(strsplit.matrix(strsplit.matrix(a[pos], "_")[,2], "\\.")[,1]), na.rm=T)
    fname <- paste("RPlot_", a+1, ".pdf", sep="")
  }
  pdf(fname, w, h, ...)
}

#Order complex vectors
orderComplex <- function(x, decreasing=F) {
	options(warn=-1)
	ct <- nt <- NULL
	pos <- 2
	part <- substr(x, 1, 1)
	while(any(part!="")) {
		nt1 <- ct1 <- part
		nt1[is.na(as.numeric(nt1))] <- ""
		nt <- paste(nt, nt1, sep="")
		ct1[!is.na(as.numeric(ct1))] <- ""
		ct <- paste(ct, ct1, sep="")
		part <- substr(x, pos, pos)
		pos <- pos + 1
	}
	options(warn=0)
	order(as.numeric(nt), ct, decreasing=decreasing)
}

#Open default device for output
deviceScreen <- function(w=7, h=7, ...) {
  switch(pmatch(Sys.info()[1], c("Linux", "Darwin", "Windows")),
  x11(w=w, h=h, ...),
  x11(w=w, h=h, ...),
  windows(w=w, h=h, ...))
}

#' Four parameters sigmoid curve between 0 and 1
#'
#' This function transform a numerical vector using a sigmoidal function between 0 and 1
#'
#' @param x Numerical vector
#' @param slope Number indicating the curve slope at the inflection point
#' @param inflection Number indicating the inflection point
#' @return Numerical vector between 0 and 1
#' @export

sigT <- function (x, slope=20, inflection=.5) 1-1/(1+exp(slope*(x-inflection)))

#' jaccard distance
#' 
#' This function computes the jaccard distance between two vectors or the columns of a matrix
#' 
#' @param x Vector or matrix
#' @param y Optional vector
#' @return Jaccard distance or vector of jaccard distances
#' @export
jaccard <- function(x, y=NULL) {
    if (is.matrix(x)) {
        tmp <- lapply(1:(ncol(x)-1), function(i, x) {
            apply(filterColMatrix(x, (i+1):ncol(x)), 2, function(x1, x2) {
                jaccard(x1, x2)
            }, x2=x[, i])
        }, x=x)
        tmp <- unlist(tmp, use.names=FALSE)
        ji <- matrix(1, ncol(x), ncol(x))
        ji[lower.tri(ji)] <- tmp
        ji <- t(ji)
        ji[lower.tri(ji)] <- tmp
        rownames(ji) <- colnames(ji) <- colnames(x)
        ji[is.na(ji)] <- 0
        return(ji)
    }
    sum(x&y)/sum(x|y)
}

