# Generates tables in html format
#' HTML table of results
#' 
#' This function produce html files containing tables of results
#' 
#' @param table Dataframe containing the data for the table. The first column contains the entrezID, GO or KEGG ID
#' @param filename Character string indicating the name of the output file wit no extension
#' @param title Character string indicating the title for the table
#' @param html.title Character string indicating the title for the html file
#' @param repository Character string indicating the repository for the ID, wither ll for entrez-gene, go for GO, or kegg for KEGG pathways
#' @return Nothing, a html file is generated
#' @export
html.table <- function(table, filename, title="", html.title="", repository=c("ll", "go", "kegg")[1]) {
  if (!is.data.frame(table)) table <- as.data.frame(table)
  htmltable(genelist=table[, 1], filename=filename, title=title, othernames=table[, -1], table.head=colnames(table), repository=repository, html.title=html.title)
}


#Internal
htmltable <- function (genelist, filename, title, othernames, table.head,
    table.center = TRUE, repository = c("ll","go","kegg")[1], html.title="Differentially Expressed Genes")
{
    outfile <- file(filename, "w")
    type <- "text/css"
    cat("<html>", "<head>", paste("<TITLE>",html.title,"</TITLE>",sep=""),
        "</head>", "<body bgcolor=#FFFFFF >", paste("<H1 ALIGN=CENTER > ",html.title," </H1>",sep=""),
        paste("<style type=", type, ">", sep = ""), "p{ margin-top: 1px; margin-bottom: 1px; padding-left: 10px; text-indent: -10px }",
        "</style>", file = outfile, sep = "\n")
    if (!missing(title))
        cat("<CENTER><H1 ALIGN=\"CENTER\">", title, " </H1></CENTER>\n",
            file = outfile, sep = "\n")
    if (table.center)
        cat("<CENTER> \n", file = outfile)
    cat("<TABLE BORDER=4>", file = outfile, sep = "\n")
    if (!missing(table.head)) {
        headout <- paste("<TH>", table.head, "</TH>")
        cat("<TR>", headout, "</TR>", file = outfile, sep = "\n")
    }
    if (is.list(genelist)) {
        if (all.equal(rep(length(genelist[[1]]), length(genelist)),
            unlist(lapply(genelist, length), use.names = FALSE))) {
            nrows <- length(genelist[[1]])
        }
        else stop("The lists of genes to annotate must all be of equal length.")
    }
    else nrows <- length(genelist)
    if (is.list(repository)) {
        rows <- ""
        for (i in seq(along = repository)) {
            rows <- paste(rows, getTDRows1(genelist[[i]], repository[[i]]))
        }
    }
    else {
      if (repository=="none") rows <- paste("<TD>", genelist, "</TD>", sep="")
      else rows <- getTDRows1(genelist, repository)
    }
    if (!missing(othernames)) {
        if (is.list(othernames)) {
            others <- ""
            for (nmm in 1:length(othernames)) {
                nm <- as.vector(othernames[[nmm]])
                if (is.matrix(nm)) {
                  for (i in 1:dim(nm)[2]) {
                    others <- paste(others, "<TD>", nm[, i],
                      "</TD>", sep = "")
                  }
                }
                if (is.list(nm)) {
                  out <- vector()
                  for (j in seq(along = nm)) {
                    out[j] <- paste("<P>", nm[[j]], "</P>", sep = "",
                      collapse = "")
                  }
                  out <- paste("<TD>", out, "</TD>", sep = "")
                  others <- paste(others, out, sep = "")
                }
                if ((is.vector(nm) || is.factor(nm)) && !is.list(nm))
                  others <- paste(others, "<TD>", nm, "</TD>",
                    sep = "")
            }
        }
        else others <- paste("<TD>", othernames, "</TD>", sep = "")
        if (length(rows) != length(others))
            stop(paste("There are", length(rows), "rows in your genelist, but",
                length(others), "rows in othernames.\n This will not give",
                "good results!\n"))
        rows <- paste(rows, others)
    }
    for (i in 1:nrows) cat("<TR>", rows[i], "</TR>", file = outfile,
        sep = "\n")
    cat("</TABLE>", file = outfile)
    if (table.center)
        cat("</CENTER> \n", file = outfile)
    cat("</body>", "</html>", sep = "\n", file = outfile)
    close(outfile)
}

getTDRows1 <- function (ids, repository = "ug")
{
    out <- paste("<TD>", getCells1(ids, repository), "</TD>",
        sep = "")
    return(out)
}
 getCells1 <- function (ids, repository = "ug")
{
    if (is.list(ids)) {
        out <- vector()
        temp <- lapply(ids, getQueryLink1, repository = repository)
        for (i in seq(along = ids)) {
            if (temp[i] != "&nbsp;")
                out[i] <- paste("<P><A HREF=\"", temp[[i]], "\">",
                  ids[[i]], "</A></P>", sep = "", collapse = "")
            else out[i] <- temp[i]
        }
    }
    else {
        temp <- getQueryLink1(ids, repository)
        blanks <- temp == "&nbsp;"
        out <- paste(" <A HREF=\"", temp, "\">", ids, "</A>",
            sep = "")
        out[blanks] <- "&nbsp;"
    }
    return(out)
}

#Query for GO database
getQueryLink1 <- function (ids, repository = "ug")
{
    switch(tolower(repository), ug = return(getQuery4UG(ids)),
        ll = return(getQuery4LL(ids)), affy = return(getQuery4Affy(ids)),
        gb = return(getQuery4GB(ids)), sp = return(getQuery4SP(ids)),
        omim = return(getQuery4OMIM(ids)), fb = return(getQuery4FB(ids)),
        en = return(getQuery4EN(ids)), go = return(getQuery4GO(ids)), kegg = return(getQuery4KEGG(ids)), se=return(getQuery4SE(ids)),
        stop("Unknown repository name"))
}

getQuery4GO <- function (ids)
{
    if (is.factor(ids)) {
        options(warn = -1)
        ids <- as.character(ids)
        options(warn = 0)
        blanks <- is.na(ids)
    }
    if (is.character(ids))
        blanks <- is.na(ids)
    out <- paste("http://amigo.geneontology.org/cgi-bin/amigo/term-details.cgi?term=",
        ids, sep = "")
    out[blanks] <- "&nbsp;"
    return(out)
}

getQuery4KEGG <- function (ids)
{
  out <- paste("http://www.genome.ad.jp/dbget-bin/www_bget?path:hsa",ids,sep="")
  out[is.na(ids)] <- "&nbsp;"
  return(out)
}

getQuery4LL <- function (ids)
{
  out <- paste("http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?db=gene&cmd=Retrieve&dopt=Graphics&list_uids=",ids,sep="")
  out[is.na(ids)] <- "&nbsp;"
  return(out)
}

getQuery4SE <- function(ids){
  out <- paste("http://www.ncbi.nlm.nih.gov/sites/entrez?db=gene&cmd=search&term=",ids,sep="")
  out[is.na(ids)] <- "&nbsp;"
  return(out)
}

htmltable.txt <- function (genelist, title, othernames, table.head,
    table.center = TRUE, repository = c("ll","go","kegg")[1], html.title="Differentially Expressed Genes")
{
    type <- "text/css"
    t <- paste(paste("<style type=", type, ">", sep = ""), "p{ margin-top: 1px; margin-bottom: 1px; padding-left: 10px; text-indent: -10px }",
        "</style>", sep = "\n")
    if (!missing(title))
        t <- paste(t,"<CENTER><H2 ALIGN=\"CENTER\">", title, " </H2></CENTER>\n",
            sep = "\n")
    if (table.center)
        t <- paste(t,"<CENTER> \n")
    t <- paste(t,"<TABLE BORDER=4>", sep = "\n")
    if (!missing(table.head)) {
        headout <- paste("<TH>", table.head, "</TH>")
        t <- paste(t,"<TR>", paste(headout,collapse="\n"), "</TR>", sep = "\n")
    }
    if (is.list(genelist)) {
        if (all.equal(rep(length(genelist[[1]]), length(genelist)),
            unlist(lapply(genelist, length), use.names = FALSE))) {
            nrows <- length(genelist[[1]])
        }
        else stop("The lists of genes to annotate must all be of equal length.")
    }
    else nrows <- length(genelist)
    if (is.list(repository)) {
        rows <- ""
        for (i in seq(along = repository)) {
            rows <- paste(rows, getTDRows1(genelist[[i]], repository[[i]]))
        }
    }
    else rows <- getTDRows1(genelist, repository)
    if (!missing(othernames)) {
        if (is.list(othernames)) {
            others <- ""
            for (nmm in 1:length(othernames)) {
                nm <- as.vector(othernames[[nmm]])
                if (is.matrix(nm)) {
                  for (i in 1:dim(nm)[2]) {
                    others <- paste(others, "<TD>", nm[, i],
                      "</TD>", sep = "")
                  }
                }
                if (is.list(nm)) {
                  out <- vector()
                  for (j in seq(along = nm)) {
                    out[j] <- paste("<P>", nm[[j]], "</P>", sep = "",
                      collapse = "")
                  }
                  out <- paste("<TD>", out, "</TD>", sep = "")
                  others <- paste(others, out, sep = "")
                }
                if ((is.vector(nm) || is.factor(nm)) && !is.list(nm))
                  others <- paste(others, "<TD>", nm, "</TD>",
                    sep = "")
            }
        }
        else others <- paste("<TD>", othernames, "</TD>", sep = "")
        if (length(rows) != length(others))
            stop(paste("There are", length(rows), "rows in your genelist, but",
                length(others), "rows in othernames.\n This will not give",
                "good results!\n"))
        rows <- paste(rows, others)
    }
    for (i in 1:nrows) t <- paste(t,"<TR>", rows[i], "</TR>",sep = "\n")
    t <- paste(t,"</TABLE>")
    if (table.center)
        t <- paste(t,"</CENTER> \n")
    t
}

