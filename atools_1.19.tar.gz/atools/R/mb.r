#Molecular Biology functions

#' Oligo thermodynamics
#'
#' This function estimates thermodynamic parameters (dG and TM) for dsDNA oligos based on their sequence
#'
#' @param x Vector of character strings indicating the oligo sequences
#' @param temp Temperature in centigrades
#' @param oligo Oligonucleotide molar concentration
#' @return deltaG and melting temperature
#' @export

oligoThermo <- function(x, temp=60, oligo=1e-9) {
  dH <- rep(c(-7.9, -7.2, -7.2, -8.5, -8.4, -7.8, -8.2, -10.6, -9.8, -8.0, 2.3, 0.1), 2)
  dS <- rep(c(-22.2, -20.4, -21.3, -22.7, -22.4, -21.0, -22.2, -27.2, -24.4, -19.9, 4.1, -2.8), 2)/1000
  names(dH) <- names(dS) <- c("AA", "AT", "TA", "CA", "GT", "CT", "GA", "CG", "GC", "GG", "A", "G", "TT", "AT", "TA", "TG", "AC", "AG", "TC", "CG", "GC", "CC", "T", "C")
  dH <- dH[!duplicated(names(dH))]
  dS <- dS[!duplicated(names(dS))]
  if (all(sapply(x, nchar)==nchar(x[1]))) {
    tmp <- sapply(1:(nchar(x[1])-1), function(i, x) substr(x, i, i+1), x=x)
    sH <- dH[match(tmp, names(dH))]
    sS <- dS[match(tmp, names(dS))]
    dim(sH) <- dim(sS) <- dim(tmp)
    sH <- rsum(sH)[, 1]
    sS <- rsum(sS)[, 1]
    names(sH) <- names(sS) <- names(x)
    dG <- sH-(temp+273.15)*sS
    tm <- sH/(sS+1.987*log(oligo)/1000)-273.15
    return(list(dG=dG, tm=tm))
  }
  stop("Oligonucleotides of different length were not implemented yet", call.=F)
}

