#' Fisher p-value integration
#'
#' This function computes integrated p-values using Fisher's method
#'
#' @param pval Vector of p-values to integrate
#' @return Integrated p-value
#' @export

meta.fisher <- function(pval) {
  tmp <- -2*sum(log(pval))
  pchisq(tmp, 2*length(pval), lower.tail=F)
}

