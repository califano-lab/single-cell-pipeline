#' Principal Component Analysis Plots
#'
#' This function generates a scatter-plot of two principal components
#'
#' @param dset Matrix of expression data, with genes in rows and samples in columns
#' @param clases Character vector of classes to color
#' @param pc Vector of two integers indicating the principal components to include in the plot
#' @param center Logical, whether the data should be centered before principal components analysis
#' @param scale. Logical, whether the data should be scaled before principal components analysis
#' @param labels Logical, whether labels should be included
#' @return Nothing, a plot is generated as side effect
#' @export

#Plot of a couple of PCs
pcplot <- function(dset, clases=colnames(dset), pc=1:2, center=T, scale.=F, labels=TRUE, ...) {
  tmp <- prcomp(t(dset), center=center, scale.=scale.)
  d2 <- t(tmp$x)
  pvar <- tmp$sdev^2/sum(tmp$sdev^2)
  col <- c("#000000FF", rainbow(length(unique(clases))-1, s=1, v=.8, 0, .66))
  col <- col[match(clases, unique(clases))]
  tt <- "p"
  if (labels) tt <- "n"
  plot(d2[pc[1], ], d2[pc[2], ], type=tt, xlim=range(d2[pc[1], ])+c(-.3, .2)*max(abs(range(d2[pc[1], ]))), ylim=range(d2[pc[2], ])+c(-.1, .1)*max(abs(range(d2[pc[2], ]))), xlab=paste("PC", "-", pc[1], ", var: ", signif(pvar[pc[1]]*100, 2), "%", sep=""), ylab=paste("PC", "-", pc[2], ", var: ", signif(pvar[pc[2]]*100, 2), "%", sep=""), col=col, ...)
  if (labels) text(d2[pc[1], ], d2[pc[2], ], colnames(d2), adj=.5, col=col, font=2)
}

#' Barplot for the variance accounted by each component
#'
#' This function generates a bar-plot for the variance accounted by each principal component
#'
#' @param dset Expression dataset in matrix format, with genes in rows and samples in columns
#' @param cutoff Number indiating the cummulative variance explained threshold to color the bars
#' @param bars Maximum number of bars
#' @param center Logical, whether the data should be centered before principal components analysis
#' @param scale. Logical, whether the data should be scaled before principal components analysis
#' @return Nothing, a plot i generated as side effect
#' @export

pcvar <- function(dset, cutoff=90, bars=10, center=T, scale.=F, ...) {
  if (bars > min(dim(dset))) bars <- min(dim(dset))
  d2 <- t(prcomp(t(dset), center=center, scale.=scale.)$x)
  tmp1 <- as.vector(rvar(d2))
  tmp <- cumsum(tmp1)
  tmp <- tmp*100/tmp[length(tmp)]
  pos1 <- which(tmp>cutoff)[1]
  if (pos1>bars) col1 <- rep("blue", bars)
  else col1 <- c(rep("blue", pos1), rep("grey", bars-pos1))
  barplot(tmp1[1:bars]/sum(tmp1)*100, names.arg=1:bars, xlab="Principal component", ylab="Variance", col=col1, ...)
}

svdplot <- function(dset, clases=colnames(dset), pc=1:2, ...) {
  d2 <- svd(dset)
  col <- c("#000000FF", rainbow(length(unique(clases))-1, s=1, v=.8, 0, .66))
  col <- col[match(clases, unique(clases))]
  plot(d2$v[, pc[1]], d2$v[, pc[2]], type="n", xlim=range(d2$v[, pc[1]])+c(-.3, .2)*max(abs(range(d2$v[, pc[1]]))), ylim=range(d2$v[, pc[2]])+c(-.1, .1)*max(abs(range(d2$v[, pc[2]]))), xlab=paste("PC", pc[1], sep="-"), ylab=paste("PC", pc[2], sep="-"), ...)
  text(d2$v[, pc[1]], d2$v[, pc[2]], colnames(dset), adj=.5, col=col, font=2)
}

svdvar <- function(dset, cutoff=90, bars=1:10, ...) {
  d2 <- svd(dset)
  tmp1 <- d2$d^2
  tmp <- cumsum(tmp1)
  tmp <- tmp*100/tmp[length(tmp)]
  pos1 <- which(tmp>cutoff)[1]
  if (pos1>max(bars)) col1 <- rep("blue", max(bars))
  else col1 <- c(rep("blue", pos1), rep("grey", max(bars)-pos1))
  barplot(tmp1[bars]/sum(tmp1)*100, names.arg=bars, xlab="Principal component", ylab="Variance", col=col1[bars], ...)
}

#' PCA outliers
#' 
#' This function detects outliers based on SVD
#' 
#' @param dset Data in matrix form, with samples in columns and features in rows
#' @param groups Optional vector of group labels
#' @param method Character string indicating the method to infer outliers, either sd or ttest
#' @param integrated Logical, whether the dimensions should be integrated using Euclidean distance
#' @export
pcoutlier <- function(dset, groups=NULL, method=c("sd", "ttest")) {
    method <- match.arg(method)
    if (is.null(groups)) groups <- rep(1, ncol(dset))
    rdset <- apply(dset, 2, function(x) sample(x))
    rownames(rdset) <- rownames(dset)
    svd1 <- svd(scale(t(dset)), nv=0)
    pvar <- svd1$d^2/sum(svd1$d^2)
    pc1 <- diag(svd1$d) %*% t(svd1$u)
    colnames(pc1) <- colnames(dset)
    rsvd1 <- svd(scale(t(rdset)), nv=0)
    rpvar <- rsvd1$d^2/sum(rsvd1$d^2)
    nopt <- which((pvar-rpvar)<0)[1]-1
    tmp <- tapply(1:ncol(pc1), groups, function(i, d1, method) {
        tmp <- d1[, i]
        switch(method,
            sd={
                z <- t(scale(t(tmp)))
            },
            ttest={
                z <- sapply(1:ncol(tmp), function(i, tmp) {
                    tmp <- rowTtest(tmp[, i]-filterColMatrix(tmp, (1:ncol(tmp))[-i]))
                    qnorm(tmp$p.value[, 1]/2, lower.tail=FALSE)*sign(tmp$statistic[, 1])
                }, tmp=tmp)
            }
        )
        rownames(z) <- paste("pc", 1:nrow(z), sep="")
        colnames(z) <- colnames(tmp)
        return(z)
    }, d1=filterRowMatrix(pc1, 1:nopt), method=method)
    pos <- order(unlist(split(1:ncol(pc1), groups), use.names=FALSE))
    z <- NULL
    for (i in 1:length(tmp)) z <- cbind(z, tmp[[i]])
    z <- filterColMatrix(z, pos)
    return(z)
}

#' pcaBatchNorm
#' 
#' This function removes the variance componen most associated with batch effect
#' 
#' @param dset Expression matrix with genes as rows and samples as columns
#' @param batch Vector of batch ids
#' @param method Character string indicating the method of choice for removing the batch effect
#' @param adjust Character string indicating the method for multiple hypothesis correction
#' @param thr Number indicating the p-value threshold
#' @param verbose Logical, whether text feedback should be provided
#' @return Normalized dataset
#' @export
pcaBatchNorm <- function(dset, batch, method=c("eigenvalue", "mean", "median", "mode"), adjust="fdr", thr=.05, verbose=FALSE) {
    method <- match.arg(method)
    tmp <- svd(t(dset-rowMeans(dset)))
    pc <- tmp$u %*% diag(tmp$d)
    res <- dset
    if (method %in% c("mean", "median", "mode")) {
        switch(method,
        mean={pcm <- colMeans(pc)},
        median={pcm <- apply(pc, 2, median)},
        mode={pcm <- apply(pc, 2, distMode)})
        pc <- t(t(pc)-as.vector(pcm))
        res <- t(pc %*% t(tmp$v))
    }
    if (method=="eigenvalue") {
        rdset <- apply(dset, 2, sample)
        rownames(rdset) <- rownames(dset)
        rpc <- svd(t(rdset-rowMeans(rdset)))$d
        rpc <- rpc/sum(rpc)
        pcmax <- which(rpc>(tmp$d/sum(tmp$d)))[1]-1
        treat <- factor(batch)
        design <- model.matrix(~0+treat)
        colnames(design) <- levels(treat)
        fit <- eBayes(lmFit(t(pc)[1:pcmax, ], design))$F.p.value
        pos <- which(p.adjust(fit, adjust)<thr)
        if (verbose) {
            message("Data normalization by removing the following components:")
            message(paste(pos, collapse=", "))
        }
        tmp$d[pos] <- 0
        res <- t(tmp$u %*% diag(tmp$d) %*% t(tmp$v))
    }
    colnames(res) <- colnames(dset)
    rownames(res) <- rownames(dset)
    res
}

#' replicateSimilarity
#' 
#' This function computes the similarity intra and inter replicates
#' 
#' @param dset Numeric matrix with genes in rows and samples in columns
#' @param groups Optimal vector indicating hte replicate groups, taking from dset colnames if missing
#' @param pca Logical, whether the analysis should be performed in principal components space
#' @param distance Character string indicating the distance to be used. PCA method uses only euclidean distance
#' @param nn Optional integer indicating the number of genes to be used for the viperSimilarity
#' @return List containing the similarity scores for intra and inter replicated data
#' @export
replicateSimilarity <- function(dset, groups=NULL, disgroups=NULL, pca=FALSE, distance=c("correlation", "euclidean", "viperSimilarity"), nn=NULL) {
    distance <- match.arg(distance)
    if (is.null(groups)) groups <- colnames(dset)
    if (is.null(disgroups)) disgroups <- colnames(dset)
    if (pca) {
        rdset <- apply(dset, 2, sample)
        rownames(rdset) <- rownames(dset)
        svd1 <- svd(t(dset-rowMeans(dset)))
        svd2 <- svd(t(rdset-rowMeans(rdset)))
        pcmax <- which((svd2$d/sum(svd2$d))>(svd1$d/sum(svd1$d)))[1]-1
        dd <- as.matrix(dist((svd1$u %*% diag(svd1$d))[, 1:pcmax]))
        colnames(dd) <- rownames(dd) <- colnames(dset)
    }
    else {
        switch(distance,
            correlation={dd <- 1-cor(dset)},
            euclidean={dd <- as.matrix(dist(t(dset-rowMeans(dset))))},
            viperSimilarity={dd <- as.matrix(as.dist(viperSimilarity(dset-rowMeans(dset), nn=nn)))}
        )
    }
    colnames(dd) <- rownames(dd) <- groups
    replic <- table(colnames(dd))
    intra <- unlist(lapply(names(replic)[replic>1], function(samp, dd) {
        pos <- colnames(dd)==samp
        tmp <- dd[pos, ][, pos]
        tmp[upper.tri(tmp)]
    }, dd=dd), use.names=FALSE)
    colnames(dd) <- rownames(dd) <- disgroups
    replic <- table(colnames(dd))
    inter <- unlist(lapply(names(replic), function(samp, dd) {
        pos <- rownames(dd)==samp
        tmp <- dd[, !pos][pos, ]
    }, dd=dd), use.names=FALSE)
    list(intra=intra, inter=inter)
}
