#Unify expsets and go.results for a set of expression-set objects
unify <- function(expset) {
  d <- expset.undeep(expset)
  if (length(d)<2) stop("expset must be a list of expression-set objects")
  genes <- nodes <- snodes <- NULL
  genes <- unlist(lapply(d, function(x) rownames(x$expset)), use.names=F)
  nodes <- unlist(lapply(d, function(x) names(x$go.result$p.value)), use.names=F)
  snodes <- unlist(lapply(d, function(x) names(x$go.tree)), use.names=F)
  if (length(genes)>0) {
    ngenes <- tapply(genes, factor(genes), length)
    genes <- names(ngenes)[ngenes==length(d)]
  }
  if (length(nodes)>0) {
    nnodes <- tapply(nodes, factor(nodes), length)
    nodes <- names(nnodes)[nnodes==length(d)]
  }
  if (length(snodes)>0) {
    nsnodes <- tapply(snodes, factor(snodes), length)
    snodes <- names(snodes)[nsnodes==length(d)]
  }
  unify.i(expset,genes,nodes,snodes)
}

unify.i <- function(x,genes,nodes,snodes) {
  if (names(x)[1]=="expset") {
    x$expset <- filterRowMatrix(x$expset,rownames(x$expset) %in% genes)
    if (!is.null(x$qs)) x$qs <- filterRowMatrix(x$qs,rownames(x$qs) %in% genes)
    if (!is.null(x$fold)) x$fold <- filterRowMatrix(x$fold,rownames(x$fold) %in% genes)
    if (!is.null(x$p.value)) x$p.value <- filterRowMatrix(x$p.value,rownames(x$p.value) %in% genes)
    if (!is.null(x$gene)) x$gene <- x$gene[names(x$gene) %in% genes]
    if (!is.null(x$description)) x$description <- x$description[names(x$description) %in% genes]
    if (!is.null(x$class)) x$class <- x$class[names(x$class) %in% genes]
    if (!is.null(x$go.class)) x$go.class <- x$go.class[names(x$go.class) %in% genes]
    if (!is.null(x$go.result$fold)) x$go.result$fold <- x$go.result$fold[names(x$go.result$fold) %in% nodes]
    if (!is.null(x$go.result$p.value)) x$go.result$p.value <- x$go.result$p.value[names(x$go.result$p.value) %in% nodes]
    if (!is.null(x$go.tree)) x$go.tree <- x$go.tree[names(x$go.tree) %in% snodes]
    x
  }
  else lapply(x, unify.i, genes=genes, nodes=nodes, snodes=snodes)
}
