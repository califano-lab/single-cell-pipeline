#' Translating species to species number
#'
#' This function generates TaxID from species names
#'
#' @param specie Character string indicating the species name
#' @return TaxID
#' @export

which.specie <- function(specie) {
  res <- unlist(lapply(specie, which.specie.i), use.names=F)
  names(res) <- unlist(sapply(specie, function(x) names(which.specie.i(x))), use.names=F)
  res
}

which.specie.i <- function(specie) {
  switch(match.arg(specie, choices=c("Mus musculus","Rattus novergicus","Magnaporthe grisea","Kluyveromyces lactis","Eremothecium gossypii","Arabidopsis thaliana","Oryza sativa","Schizosaccharomyces pombe","Saccharomyces cerevisiae","Neurospora crassa","Plasmodium falciparum","Caenorhabditis elegans","Anopheles gambiae","Drosophila melanogaster","Gallus gallus","Pan troglodytes","Homo sapiens","Canis familiaris")),
    "Mus musculus"=c("Mus musculus"=10090),
    "Rattus novergicus"=c("Rattus novergicus"=10116),
    "Magnaporthe grisea"=c("Magnaporthe grisea"=148305),
    "Kluyveromyces lactis"=c("Kluyveromyces lactis"=28985),
    "Eremothecium gossypii"=c("Eremothecium gossypii"=33169),
    "Arabidopsis thaliana"=c("Arabidopsis thaliana"=3702),
    "Oryza sativa"=c("Oryza sativa"=4530),
    "Schizosaccharomyces pombe"=c("Schizosaccharomyces pombe"=4896),
    "Saccharomyces cerevisiae"=c("Saccharomyces cerevisiae"=4932),
    "Neurospora crassa"=c("Neurospora crassa"=5141),
    "Plasmodium falciparum"=c("Plasmodium falciparum"=5833),
    "Caenorhabditis elegans"=c("Caenorhabditis elegans"=6239),
    "Anopheles gambiae"=c("Anopheles gambiae"=7165),
    "Drosophila melanogaster"=c("Drosophila melanogaster"=7227),
    "Gallus gallus"=c("Gallus gallus"=9031),
    "Pan troglodytes"=c("Pan troglodytes"=9598),
    "Homo sapiens"=c("Homo sapiens"=9606),
    "Canis familiaris"=c("Canis familiaris"=9615))
}

