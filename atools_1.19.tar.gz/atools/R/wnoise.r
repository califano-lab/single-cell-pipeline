#' Add white nose to a dataset
#'
#' This function adds white noise to a dataset
#' @param dset Numerical matrix
#' @param f Number indicating the standard deviation for the white noise
#' @return numerical matrix
#' @export

wnoise <- function(dset, f=1e-3) {
  a <-which(apply(dset, 1, function(x) length(levels(factor(x))))<ncol(dset))
  maxn <- max(abs(dset), na.rm=T)
  dset[a, ] <- dset[a, ]+rnorm(length(dset[a, ]), 0, f)
  return(dset)
}

